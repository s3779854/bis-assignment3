-----Info-----
The game has a couple of bugs that may occur; the main one being sometimes getting stuck on the floor when walking, this can be fixed by jumping.

The second being some sprites may not load on the compiled version of the game sometimes, restarting this can fix it. An enemy should be encountered when dropping down from the platform
after walking up the stairs, please restart the game if the enemy isn't visible.

---Controls---

Arrow keys - Move
Z - Dash
V - Shoot
E - Pick up item
I - Inventory

Clicking items in the inventory will use them.